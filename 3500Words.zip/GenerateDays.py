with open('3500Words.txt',encoding='utf-8') as files:
	words=files.readlines()
num=int(len(words)/2)
l=1
r=20
p=1
while l<=num:
	output='2\n'
	r=min(r,num)
	for i in range(l,r+1):
		output+=words[(i-1)*2].strip()+'\n'+words[(i-1)*2+1].strip()+'\n'
	with open('Day'+str(p)+'.txt','w',encoding='utf-8') as files:
		files.write(output)
	l=l+20
	r=r+20
	p=p+1